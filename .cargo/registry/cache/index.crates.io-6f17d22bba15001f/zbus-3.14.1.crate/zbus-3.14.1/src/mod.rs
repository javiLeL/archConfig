//! The asynchronous API.
//!
//! This module hosts all our asynchronous API.


pub use crate::raw::Socket;
